
CREATE TYPE city_suburb AS (
    city	varchar,
    suburb	varchar
);
CREATE TYPE city_suburb_time AS (
    city 	varchar,
    suburb	varchar,
    time	timestamp
);

CREATE TYPE city_suburb_time_job AS (
    city 	varchar,
    suburb	varchar,
    time	timestamp,
    job		int,
    PU		boolean,
    time_bound	timestamp,
    order_type	varchar(1)
);

CREATE type cargo_specs AS (
    mass	float,
    vol		float,
    count	int,
    dim		float[3]
);

CREATE OR REPLACE FUNCTION timeinterval_2_float(ti interval)
    RETURNS float AS
$$
DECLARE
    rec float;
BEGIN
    SELECT extract('minute' FROM ti) / 60.0 + extract('hour' FROM ti) INTO rec;
    return rec;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;

CREATE OR REPLACE FUNCTION city_from_id(int)
    RETURNS varchar AS 'select city from trans_identity_address where id = $1'
LANGUAGE 'sql';

CREATE OR REPLACE FUNCTION suburb_from_id(int)
    RETURNS varchar AS 'select suburb from trans_identity_address where id = $1'
LANGUAGE 'sql';

  

CREATE OR REPLACE FUNCTION major_cityname_from_id(int)
    RETURNS varchar AS 'select major_name from gps_city where id = $1'
LANGUAGE 'sql';

CREATE OR REPLACE FUNCTION cityname_from_id(int)
    RETURNS varchar AS 'select name from gps_city where id = $1'
LANGUAGE 'sql';


CREATE OR REPLACE FUNCTION cityid_from_name(int)
    RETURNS int AS 'select id from gps_city where $1 = name'
LANGUAGE 'sql';



--
-- Create an ordered list of destinations to be visited between the two times (inclusive)
--
CREATE OR REPLACE FUNCTION ordered_destinations(time1 timestamp,driver int)
    RETURNS SETOF city_suburb_time_job AS
$$
DECLARE
    row record;
    cst city_suburb_time_job;
BEGIN
    FOR row in SELECT * FROM ( SELECT city_from_id(pickup) as city,suburb_from_id(pickup) AS suburb, sched_pu AS time , order_no as job , true as PU , daytime as time_bound,order_type FROM only trans_order WHERE sched_pu >= time1 and driver_id = driver and job_status in ('a') UNION SELECT city_from_id(deliver) AS city,suburb_from_id(deliver) AS suburb, sched_d AS time, order_no as job  , false as PU, latest_daytime as time_bound,order_type FROM only trans_order WHERE sched_d >= time1 and driver_id = driver and job_status in ('a','c')) as unioned ORDER BY time ASC
    LOOP
	cst.city := row.city;
	cst.suburb := row.suburb;
	cst.time := row.time;
	cst.pu := row.pu;
	cst.job := row.job;
	cst.time_bound := row.time_bound;
	cst.order_type := row.order_type;
	RETURN NEXT cst;
    END LOOP;
    RETURN;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;

CREATE OR REPLACE FUNCTION ordered_destinations(timestamp,timestamp,int)
    RETURNS SETOF city_suburb_time_job AS
$$
    SELECT * FROM ordered_destinations($1::timestamp,$3) where time <= $2::timestamp
$$
LANGUAGE 'sql';

CREATE OR REPLACE FUNCTION reverse_ordered_destinations(timestamp,int)
    RETURNS SETOF city_suburb_time_job AS
$$
    SELECT * FROM ordered_destinations($1::timestamp - '99 years'::interval,$1::timestamp,$2) ORDER BY time DESC
$$
LANGUAGE 'sql';


--
-- Fetch the job numbers of jobs current at the specified time.
-- NB. includes jobs picked up at time but not dropped since will assume can
-- drop off before picking up further cargo.
-- Call as : current_jobs(time,driver_id)
--
CREATE OR REPLACE FUNCTION current_jobs(timestamp,int)
    RETURNS SETOF int AS 
$$
select order_no as job_number from only trans_order where sched_pu <= $1 and sched_d > $1 and driver_id = $2 and job_status not in ('x','X','d','D')
$$
LANGUAGE 'sql';


--
-- Calculate the net cargo loaded at specified time by specified driver
-- .. assumes that unloadable cargo at this time is unloaded first.
--
--CREATE OR REPLACE FUNCTION current_load_py(times text,driver_id int)
--    RETURNS cargo_specs AS
--$$
--    # find the cumulative mass & volume
--    rows = plpy.execute("select max(item_dimensions) as dim, count(net_mass) as count,sum(net_mass) as mass, sum(packed_volume) as vol from trans_job_order where job_number in (select * from current_jobs('%s'::timestamp,%s))" % (times,driver_id))
--    mass = rows[0]['mass']
--    vol = rows[0]['vol']
--    cnt = rows[0]['count']
--    dim = rows[0]['dim']  	# largest single item ???
--    return mass,vol,cnt,dim
--$$
--LANGUAGE 'plpythonu'  VOLATILE STRICT;
-- plpgsql version of above function
CREATE OR REPLACE FUNCTION current_load(times timestamp,driver_id int)
    RETURNS cargo_specs AS
$$
DECLARE
    row record;
    result cargo_specs;
BEGIN
    -- find the cumulative mass & volume
    SELECT  sum(packed_volume) as vol, sum(net_mass) as mass, count(net_mass) as count ,max(item_dimensions) as dim FROM trans_order WHERE order_no in ( SELECT * FROM current_jobs(times,driver_id)) INTO row;
    result.mass = row.mass;
    result.vol = row.vol;
    result.count = row.count;
    result.dim = row.dim;
    return result;
END;
$$
LANGUAGE 'plpgsql'  VOLATILE STRICT;

-- Calculate percentage of vehicle capacity required by an order
--
CREATE OR REPLACE FUNCTION vehicle_usage(vehicle int,ord int)
    RETURNS float AS
$$
DECLARE
    row record;
BEGIN
    -- compare the order to the vehicle specifications
    SELECT b.packed_volume/(a.dim[1] * a.dim[2]) AS vol,b.net_mass/a.max_load AS load,b.net_mass/a.max_rack_load AS rackload,b.item_dimensions > a.dim AS rack_flag , b.packed_volume / (a.rack_dim[1] * a.rack_dim[2]) as rack_vol FROM ONLY trans_order b, trans_vehicles a WHERE b.order_no = ord AND a.vehicle_code = vehicle INTO row;
    IF row.rack_flag = 't'
    THEN
	IF row.rackload > row.rack_vol
	THEN
	    RETURN row.rackload;
	ELSE
	    RETURN row.rack_vol;
	END IF;
    ELSE
	IF row.load < row.vol
	THEN
	    return row.vol;
	ELSE
	    return row.load;
	END IF;
    END IF;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;


--
-- Find the next time/location at which the driver  is vacant after timestamp
--
CREATE OR REPLACE FUNCTION next_vacant_timeloc(tim timestamp,driver int)
    RETURNS city_suburb_time_job AS
$$
DECLARE
    row  record;
    row1 record;

BEGIN
    FOR row IN SELECT * FROM ordered_destinations(tim,driver) 
    LOOP
	SELECT count(*) AS count INTO row1 FROM current_jobs(row.time,driver) ;
	IF row1.count <= 0 
	    THEN
		RETURN row;
	    END IF;
    END LOOP;
-- would be an error condition to reach here !!!
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;

--
-- As above but returns the next time load is beneath the specified percentage
--
CREATE OR REPLACE FUNCTION next_vacant_timeloc(tim timestamp,driver int,load_pcnt float)
    RETURNS city_suburb_time_job AS
$$
DECLARE
    row  record;
    row1 record;
    row2 record;
    ratio_mass float;
    ratio_vol float;
    test  varchar(1);

BEGIN
    SELECT dim,dim[1]*dim[2] as max_vol,max_load,max_rack_load,rack_dim,rack_dim[1]*rack_dim[2] as max_rack_vol INTO row2 FROM trans_driver a , trans_vehicles b WHERE a.vehicle_code = b.vehicle_code AND a.id = driver;

    FOR row IN SELECT * FROM ordered_destinations(tim,driver) 
    LOOP
	SELECT * INTO row1 FROM current_load(row.time,driver) ;
	IF row1.count  = 0
	    THEN
		RETURN row;
	END IF;
	ratio_mass := row1.mass / row2.max_load;
	ratio_vol := row1.vol / row2.max_vol ;
	SELECT row1.dim > row2.dim INTO test ;
	IF test = 't'
	    THEN
		-- ie. this is a racks job, so use the racks limits
		ratio_mass := row1.mass / row2.max_rack_load;
		ratio_vol := 1.0,row1.vol / row2.max_rack_vol;
		if ratio_mass > 1.0 and ratio_mass < row2.max_load / row2.max_rack_load
		    then
			ratio_mass := 1.0; -- eg. 1000kg forr combined rack/tray
		end if;
		if ratio_vol > 1.0 and row1.vol/(row2.max_rack_vol+row2.max_vol) <= 1.0
		    then
			ratio_vol := 1.0; -- eg. assume full load if using racks + tray
		end if;
	END IF;
	IF ratio_mass > ratio_vol
	    THEN
		-- use the mass as the limiting ratio
		IF load_pcnt > ratio_mass
		    THEN
			return row;
		END IF;
	ELSE
	    -- use vol as the limiting ratio
	    IF load_pcnt > ratio_vol
		THEN
		    return row;
	    END IF;
	END IF;
    END LOOP;
    RETURN row;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;

--
-- As above but returns the list of times/destinations load is beneath the specified percentage
--
CREATE OR REPLACE FUNCTION next_vacant_timelocs(tim timestamp,driver int,load_pcnt float)
    RETURNS SETOF city_suburb_time_job AS
$$
DECLARE
    row  record;
    row1 record;
    row2 record;
    ratio_mass float;
    ratio_vol float;
    test  varchar(1);
    flag boolean;

BEGIN
    --SELECT dim,dim[1]*dim[2] as max_vol,max_load,max_rack_load,rack_dim,rack_dim[1]*rack_dim[2] as max_rack_vol INTO row2 FROM trans_driver a , trans_vehicles b WHERE a.vehicle_code = b.vehicle_code AND a.id = driver;

    FOR row IN SELECT * FROM ordered_destinations(tim,driver) 
    LOOP
	--SELECT * INTO row1 FROM current_load(row.time,driver) ;
	SELECT * FROM test_vehicle_load(row.time,driver,load_pcnt) INTO flag;
	if flag 
	    THEN
		RETURN next row;
	END IF;
    END LOOP;
    --RETURN next row;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;



--
-- Test if load is beneath specified vehicles limit at time
--
CREATE OR REPLACE FUNCTION test_vehicle_load(tim timestamp,driver int,load_pcnt float)
    RETURNS BOOLEAN AS
$$
DECLARE
    row1 record;
    row2 record;
    ratio_mass float(4);
    ratio_vol float(4);
    test  varchar(1);

BEGIN
    SELECT dim::float(4)[3],dim[1]*dim[2] as max_vol,max_load,max_rack_load,rack_dim,rack_dim[1]*rack_dim[2] as max_rack_vol INTO row2 FROM trans_driver a , trans_vehicles b WHERE a.vehicle_code = b.vehicle_code AND a.id = driver;

    SELECT mass,vol,count,dim::float(4)[3] INTO row1 FROM current_load(tim,driver) ;
    IF row1.count  = 0
	    THEN
		RETURN TRUE;
    END IF;
    ratio_mass := row1.mass / row2.max_load;
    ratio_vol := row1.vol / row2.max_vol ;
    SELECT row1.dim > row2.dim INTO test ;
    IF test = 't'
	    THEN
		-- ie. this is a racks job, so use the racks limits
		ratio_mass := row1.mass / row2.max_rack_load;
		ratio_vol := 1.0,row1.vol / row2.max_rack_vol;
		if ratio_mass > 1.0 and ratio_mass < row2.max_load / row2.max_rack_load
		    then
			ratio_mass := 1.0; -- eg. 1000kg forr combined rack/tray
		end if;
		if ratio_vol > 1.0 and row1.vol/(row2.max_rack_vol+row2.max_vol) <= 1.0
		    then
			ratio_vol := 1.0; -- eg. assume full load if using racks + tray
		end if;
    END IF;
    IF ratio_mass > ratio_vol
	    THEN
		-- use the mass as the limiting ratio
		IF load_pcnt > ratio_mass
		    THEN
			return TRUE;
		END IF;
    ELSE
	    -- use vol as the limiting ratio
	    IF load_pcnt > ratio_vol
		THEN
		    return TRUE;
	    END IF;
    END IF;
    RETURN FALSE;

END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;


create or replace function price_discounter(jobno int)
    returns float(4) as
$$
    # test whether any discounts should apply in respect of job

    import sys
    sys.path.insert(0,'/home/ftp/transport/transport/Daemons')
    import WrapGrass
    c = WrapGrass.pgRouting()

    # get the job order record
    jbos = plpy.execute("select * from trans_job_order_address where order_no = %s" % jobno)
    if len(jbos) <= 0:
	return 1.0
    else:
	jbo = jbos[0]
    
    # find the preceding & following destinations
    pre_rows = plpy.execute("select * from reverse_ordered_destinations('%s',%s) where time < date_trunc('day','%s'::timestamp) limit 1" % (jbo['sched_pu'],jbo['driver_id'],jbo['sched_pu']))

    post_rows = plpy.execute("select * from ordered_destinations('%s',%s) where date_trunc('day',time) = date_trunc('day','%s'::timestamp) limit 1" % (jbo['sched_d'],jbo['driver_id'],jbo['sched_d']))

    # fetch destinations on the same day
    concurrent_rows = plpy.execute("select * from ordered_destinations('%s',%s) where date_trunc('day',time) = date_trunc('day','%s'::timestamp)  and time > '%s'::timestamp and time < '%s'::timestamp" % (jbo['sched_pu'],jbo['driver_id'],jbo['sched_pu'],jbo['sched_pu'],jbo['sched_d']))

    scale_factor = 1.0 # percentage of full price to be charged


    if len(pre_rows) > 0 and jbo['order_type'] in ('p','P'):
	pre_row = pre_rows[0]

	custrow = plpy.execute("select customer from only trans_order where order_no = %s" % pre_row['job'])[0]
	if  pre_row['suburb'] == jbo['pu_suburb'] :
	    time_delta = plpy.execute("select '%s'::timestamp - '%s'::timestamp as tdiff" % (jbo['sched_pu'],pre_row['time']))[0]['tdiff']
	    if time_delta < '00:25:00': # dont give discount if time gap is too large
		if  jbo['customer'] == custrow['customer']:
		    # same customer current and preceding job
		    scale_factor = scale_factor * .90
		else:
		    scale_factor = scale_factor * .95 #reduce by 5% if in same suburb as prev job
    
    if len(post_rows) > 0 and jbo['order_type'] in ('p','P'):
	post_row = post_rows[0]

	custrow2 = plpy.execute("select customer from only trans_order where order_no = %s" % post_row['job'])[0]
	if post_row['suburb'] == jbo['drop_suburb']:
	    time_delta = plpy.execute("select '%s'::timestamp - '%s'::timestamp as tdiff" % (post_row['time'],jbo['sched_pu']))[0]['tdiff']
	    if time_delta < '00:25:00':  # dont give discount if time gap is too large
		if jbo['customer'] == custrow2['customer']:
		    scale_factor = scale_factor * .9
		else:
		    scale_factor = scale_factor * .95
    if len(concurrent_rows) > 0 and jbo['order_type'] in ('p','P') :
	# ... compare the total distance for each job direct with the 
	# total distance along the path
	dir_dist = jbo['distance'] # start with direct distance of the current job
	# direct distance between last concurrent dest and drop of current job
	x1,act_dist,x2 = c.time_and_dist_wextras_sub2sub(concurrent_rows[-1]['suburb'],concurrent_rows[-1]['city'],jbo['drop_suburb'],jbo['drop_city'])
	lastc = jbo['pu_city']
	lasts = jbo['pu_suburb']
	for conc_row in concurrent_rows:
	    job = plpy.execute("select * from trans_job_order_address where order_no = %s" % conc_row['job'])[0] # job for destination
	    if job['sched_pu'] < jbo['sched_pu']:
		fcity = jbo['pu_city']
		fsuburb = job['pu_suburb']
	    else:
		fcity = job['pu_city']
		fsuburb = job['pu_suburb']
	    if job['sched_d'] > jbo['sched_d']:
		lcity = jbo['drop_city']
		lsuburb = jbo['drop_suburb']
	    else:
		lcity = job['drop_city']
		lsuburb = job['drop_suburb']
	    t,d,x = c.time_and_dist_wextras_sub2sub(fsuburb,fcity,lsuburb,lcity)
	    dir_dist = dir_dist + d # add to direct distance
	    # now compute distance along path
	    t,d,x = c.time_and_dist_wextras_sub2sub(lasts,lastc,conc_row['suburb'],conc_row['city'])
	    act_dist = act_dist + d
	    lastc = conc_row['city']
	    lasts = conc_row['suburb']
	if act_dist / dir_dist > .5 or dir_dist < 80000:
	    # allow for maximum discount of 25% for concurrent orders < 80 km
	    scale_factor = scale_factor * max(min((act_dist / dir_dist),.95),0.75)
	else:
	    # allow up to 35% discount for concurrent orders > 80km
	    scale_factor = scale_factor * max(min((act_dist / dir_dist),.95),0.65)
	    

    # test for out-of-town destinations
    cty = jbo['pu_city']
    sub = jbo['pu_suburb']
    time,dist,dummy = c.time_and_dist_wextras_sub2sub('eight mile plains','brisbane',sub,cty)
    if dist > 40000:
	if len(pre_rows) > 0:
	    jtime,jdist,dummy = c.time_and_dist_wextras_sub2sub(pre_row['suburb'],pre_row['city'],jbo['pu_suburb'],jbo['pu_city'])
	    dist = min(dist,jdist-20000)
	    if dist > 0:
		scale_factor = scale_factor * ((dist + jbo['distance'])/jbo['distance'])
 
	else:
	    # greater than 40km attracts out-of-town charge
	    scale_factor = scale_factor * ((dist + jbo['distance'])/jbo['distance'])

    
    time,dist,dummy = c.time_and_dist_wextras_sub2sub('eight mile plains','brisbane',jbo['drop_suburb'],jbo['drop_city'])
    if dist > 40000:
	if len(pre_rows) > 0:
	    jtime,jdist,dummy = c.time_and_dist_wextras_sub2sub(post_row['suburb'],post_row['city'],jbo['pu_suburb'],jbo['pu_city'])
	    dist = min(dist,jdist-20000)
	    if dist > 0:
		scale_factor = scale_factor * ((dist + jbo['distance'])/jbo['distance'])
	else:
	    # greater than 40km attracts out-of-town charge
	    scale_factor = scale_factor * ((dist  + jbo['distance'])/jbo['distance'])
 
    return scale_factor
$$
language 'plpythonu' volatile strict;

create or replace function cbd_surcharge(pu_sub varchar,drop_sub varchar)
    returns float(4) as 
$$
    # adds a surcharge to the job price if it is within the Brisbane CBD
    surcharge = 0.0;

    if  pu_sub in ('brisbane','spring hill','milton','south brisbane','west end','fortitude valley'):
	surcharge = surcharge + 10.0

    if drop_sub in ('brisbane','spring hill','milton','south brisbane','west end','fortitude valley'):
	surcharge = surcharge + 10.0

    return surcharge

$$
language 'plpythonu' volatile strict;


create or replace function cbd_surcharge(job int)
    returns float(4) as 
$$
    # adds a surcharge to the job price if it is within the Brisbane CBD
    rows = plpy.execute("select * from trans_job_order_address where order_no = %s" % job)
    if len(rows) <= 0:
	return 0.0
    else:
	row = rows[0]
    surcharge = plpy.execute("select cbd_surcharge('%s','%s')" % (row['pu_suburb'],row['drop_suburb']))[0]
    return surcharge['cbd_surcharge']

$$
language 'plpythonu' volatile strict;

create or replace function out_of_town_time(job int)
    returns float(4) as 
$$
    import sys
    sys.path.insert(0,'/home/ftp/transport/transport/Daemons')
    import WrapGrass
    c = WrapGrass.pgRouting()

    rows = plpy.execute("select * from trans_job_order_address where order_no = %s" % job)
    if len(rows) <= 0:
	return 0.0
    else:
	row = rows[0]

    x1,act_dist,x2 = c.time_and_dist_wextras_sub2sub('eight mile plains','brisbane',row['pu_suburb'],row['pu_city'])
    if act_dist > 40000:
	return x1*60.0
    else:
	return 0.0

$$
language 'plpythonu' volatile strict;

create or replace function travel_dist_s2s(sub1 varchar,city1 varchar,state1 varchar,sub2 varchar,city2 varchar,state2 varchar)
    returns float(4) as 
$$
    import sys
    sys.path.insert(0,'/home/ftp/transport/transport/Daemons')
    import WrapGrass
    c = WrapGrass.pgRouting()
    try:
	x1,act_dist,x2 = c.time_and_dist_wextras_sub2sub(sub1,city1,sub2,city2,start_state=state1,target_state=state2)
    except:
	return 0.0
    return act_dist
$$
language 'plpythonu' volatile strict;

create or replace function travel_time_s2s(sub1 varchar,city1 varchar,state1 varchar,sub2 varchar,city2 varchar,state2 varchar)
    returns float(4) as 
$$
    import sys
    sys.path.insert(0,'/home/ftp/transport/transport/Daemons')
    import WrapGrass
    c = WrapGrass.pgRouting()
    try:
	x1,act_dist,x2 = c.time_and_dist_wextras_sub2sub(sub1,city1,sub2,city2,start_state=state1,target_state=state2)
    except:
	return 0.0
    return x1
$$
language 'plpythonu' volatile strict;
create or replace function install_out_of_town_traveldist(sub1 varchar,city1 varchar,state1 varchar,sub2 varchar,city2 varchar,state2 varchar,dist float(4) ,time_ varchar)
    returns int as 
$$
    import sys
    sys.path.insert(0,'/home/ftp/transport/transport/Daemons')
    import WrapGrass
    c = WrapGrass.pgRouting()
    try:
	ftimes = plpy.execute("select timeinterval_2_float('%s'::interval) as tt" % (time_,))
	t = ftimes[0]['tt']
    except:
	return 99
    try:
	c.nm_db.query("insert into out_of_town_dists values (lower('%s'),lower('%s'),lower('%s'),lower('%s'),lower('%s'),lower('%s'),%s,%s)" % (sub1,city1,state1,sub2,city2,state2,dist,t))
    except:
	return 10
    return 0
$$
language 'plpythonu' volatile strict;


