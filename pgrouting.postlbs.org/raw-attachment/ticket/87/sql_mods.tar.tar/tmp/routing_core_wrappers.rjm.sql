--
-- Copyright (c) 2005 Sylvain Pasche,
--               2006-2007 Anton A. Patrushev, Orkney, Inc.
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.


-- TODO: use spatial index when possible
-- TODO: make variable names more consistent

-- Geometry schema description:
-- gid
-- source
-- target
-- edge_id

-- BEGIN;

CREATE TYPE geoms AS
(
  id integer,
  gid integer,
  the_geom geometry
);


------------------------------------------------------------
-- Returns the n'th geometry in a collection or the first
-- if geometry is not a collection type.
--
------------------------------------------------------------
CREATE OR REPLACE FUNCTION relaxed_geometryN(geom geometry,n int)
	RETURNS geometry AS
$$
DECLARE
	row record;
BEGIN
	SELECT INTO row geometryN(ST_Multi(geom),n) as g;
	RETURN row.g;
END
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;

------------------------------------------------------------
-- Returns the N'th point in the first linestring of the 
-- geometry or null if there is no linestring in the geometry.
-- Differs from ST_PointN() in that the geometry can be a 
-- linestring instead of a multilinestring.
--
------------------------------------------------------------
CREATE OR REPLACE FUNCTION relaxed_PointN(geom geometry,n int)
	returns geometry AS
$$
DECLARE
	row record;
BEGIN
	SELECT INTO row ST_PointN(relaxed_geometryN(geom,1),n) as g;
	RETURN row.g;
END
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;


------------------------------------------------------------
-- Returns the number of points in the first linestring in the
-- geometry. Differs from st_NumPoints() in that the geometry
-- may be a simple linestring rather than a multilinestring.
------------------------------------------------------------
CREATE OR REPLACE FUNCTION relaxed_NumPoints(geom geometry)
	returns int AS
$$
DECLARE
	row record;
BEGIN
	SELECT INTO row ST_NumPoints(relaxed_geometryN(geom,1)) as c;
	RETURN row.c;
END
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;



-----------------------------------------------------------------------
-- Fill the source and target column for all lines. All line ends
--  with a distance less than tolerance, are assigned the same id
-----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION assign_vertex_id(geom_table varchar, 
       tolerance double precision)
       RETURNS VARCHAR AS
$$
DECLARE
	row record;
BEGIN
		SELECT INTO row assign_vertex_id(geom_table,tolerance,'the_geom','gid') AS r;
		return row.r;

END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT; 

-----------------------------------------------------------------------
-- Update the cost column from the edges table, from the length of
--  all lines which belong to an edge.
-----------------------------------------------------------------------
-- FIXME: directed or not ?
CREATE OR REPLACE FUNCTION update_cost_from_distance(geom_table varchar) 
       RETURNS VOID AS
$$
DECLARE 
BEGIN
	EXECUTE 'select update_cost_from_distance('||quote_literal(geom_table) ||',''cost'',''length_wgs84(the_geom)'')';
	RETURN;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT; 

-----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION update_cost_from_distance(geom_table varchar,costcol varchar,geodistfn varchar)
       RETURNS VOID AS
$$
DECLARE 
BEGIN
	EXECUTE 'UPDATE '||quote_ident(geom_table)||' SET '||
		quote_ident(costcol)||' = '||geodistfn;
		
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT; 



CREATE OR REPLACE FUNCTION length_wgs84(geom geometry)
RETURNS DOUBLE PRECISION AS
$$
DECLARE
	ans DOUBLE PRECISION;
BEGIN
		SELECT st_length_spheroid(geom,'SPHEROID["WGS_1984",6378173,298.257223563]') INTO ans;
		return ans ;
END
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;

CREATE OR REPLACE FUNCTION length_wgs84(gid integer)
RETURNS DOUBLE PRECISION AS
$$
DECLARE
	ans DOUBLE PRECISION;
BEGIN
		EXECUTE 'SELECT st_length_spheroid(the_geom,''SPHEROID["WGS_1984",6378173,298.257223563]'') FROM ways where gid = '||quote_literal(gid)||' ' INTO ans;
		return ans ;
END
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;



--
-- Find the geometry of the node(vertex) at source/target end of edge
-- NB. call this with the "(tabname))_vertices" table for tables created
-- by create_graph_tables()

CREATE OR REPLACE FUNCTION edge_geom(vertex anyelement,tab varchar)
	RETURNS geometry AS
$$
DECLARE
	geom 	geometry;
BEGIN
	EXECUTE 'select t.the_geom  from '||quote_ident(tab)||'_vertices v,vertices_tmp t where '||quote_literal(vertex)||' = v.id and v.geom_id = t.id'
	INTO geom;
	return geom;
END;
$$
LANGUAGE 'plpgsql';

--
-- Create a view to give the fields required for A* query input
-- NB. call this with tabname to operator on (tabname)_edges table

CREATE OR REPLACE FUNCTION edge_view(tab varchar)
	RETURNS VOID AS
$$
DECLARE
BEGIN
	EXECUTE 'create or replace view '||quote_ident(tab)||'_edgeview as select  gid as id,source,target, cost,st_x(edge_geom(source,'||quote_literal(tab)||')) as x1,st_y(edge_geom(source,'||quote_literal(tab)||')) as y1,st_x(edge_geom(target,'||quote_literal(tab)||')) as x2,st_y(edge_geom(target,'||quote_literal(tab)||')) as y2 from '||quote_ident(tab)||'_edges';
	RETURN;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;


-- OSM tables only
-- imports the highway type included in the osm2pgrouting import into the speed column of the 'ways' table.
--  ... eg. tab is normally set to 'ways'
CREATE OR REPLACE FUNCTION import_speed(tab varchar)
	RETURNS VOID AS
$$
DECLARE
BEGIN
	EXECUTE 'update '||quote_ident(tab)||' set speed = classes.name::integer from types,classes where types.id = classes.type_id and types.name = ''maxspeed'' and '||quote_ident(tab)||'.class_id = classes.id';

-- later extend this to set speed to defaults for different highway types
-- ... the way will have a highway type classification if no speed is known
	EXECUTE 'update '||quote_ident(tab)||' set speed = 40 where class_id >= 110 and class_id < 200';
	EXECUTE 'update '||quote_ident(tab)||' set speed = 60 where class_id = 109';
	EXECUTE 'update '||quote_ident(tab)||' set speed = 70 where class_id = 108';
	EXECUTE 'update '||quote_ident(tab)||' set speed = 70 where class_id = 107';
	EXECUTE 'update '||quote_ident(tab)||' set speed = 80 where class_id = 106';
	EXECUTE 'update '||quote_ident(tab)||' set speed = 80 where class_id = 105';
	EXECUTE 'update '||quote_ident(tab)||' set speed = 90 where class_id > 101 and class_id < 105';
	EXECUTE 'update '||quote_ident(tab)||' set speed = 100 where class_id = 101';

	RETURN;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;



-- COMMIT;
