--
-- Copyright (c) 2005 Sylvain Pasche,
--               2006-2007 Anton A. Patrushev, Orkney, Inc.
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.


-- TODO: use spatial index when possible
-- TODO: make variable names more consistent

-- Geometry schema description:
-- gid
-- source
-- target
-- edge_id

-- BEGIN;
  

-----------------------------------------------------------------------
-- For each vertex in the vertices table, set a point geometry which is
--  the corresponding line start or line end point
-----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION add_vertices_geometry(geom_table varchar,SRID int,geocol varchar) 
       RETURNS VOID AS
$$
DECLARE
	vertices_table varchar := quote_ident(geom_table) || '_vertices';
BEGIN
	
	BEGIN
		EXECUTE 'SELECT addGeometryColumn(''' || 
                        quote_ident(vertices_table)  || 
                        ''', '||quote_literal(geocol)||',' || quote_literal(SRID) ||', ''POINT'', 2)';
	EXCEPTION 
		WHEN DUPLICATE_COLUMN THEN
	END;

	EXECUTE 'UPDATE ' || quote_ident(vertices_table) || 
                ' SET '||quote_ident(geocol)||' = NULL';

	EXECUTE 'UPDATE ' || quote_ident(vertices_table) || 
                ' SET '||quote_ident(geocol)||' = startPoint(relaxed_geometryn(m.'||quote_ident(geocol)||', 1)) FROM ' ||
                 quote_ident(geom_table) || 
                ' m where geom_id = m.source';

	EXECUTE 'UPDATE ' || quote_ident(vertices_table) || 
                ' set '||quote_ident(geocol)||' = st_PointN(relaxed_geometryn(m.'||quote_ident(geocol)||', 1),st_NumPoints(relaxed_geometryN(m.'||quote_ident(geocol)||',1))) FROM ' || 
                quote_ident(geom_table) || 
                ' m where geom_id = m.target AND ' || 
                quote_ident(vertices_table) || 
                '.'||quote_ident(geocol)||' IS NULL';

	RETURN;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT; 

CREATE OR REPLACE FUNCTION add_vertices_geometry(geom_table varchar,SRID int) 
       RETURNS VOID AS
$$
BEGIN
	
	BEGIN
		EXECUTE 'SELECT add_vertices_geometry('||quote_literal(geom_table)||','||text(SRID)||',''the_geom'')';
	END;

	RETURN;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT; 

CREATE OR REPLACE FUNCTION add_vertices_geometry(geom_table varchar) 
       RETURNS VOID AS
$$
BEGIN
	
	BEGIN
		EXECUTE 'SELECT add_vertices_geometry('||quote_literal(geom_table)||',4326)';
	END;

	RETURN;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT; 



-----------------------------------------------------------------------
-- Fill the source and target column for all lines. All line ends
--  with a distance less than tolerance, are assigned the same id
-----------------------------------------------------------------------

CREATE OR REPLACE FUNCTION assign_vertex_id(geom_table varchar, 
       tolerance double precision,
       geo_cname varchar,
       gid_cname varchar)
       RETURNS VARCHAR AS
$$
DECLARE
      points record;
      i record;
      source_id int;
      target_id int;
      pre varchar;
      post varchar;
      
      srid integer;
                    			
      BEGIN
                    			
	    BEGIN
	        DROP TABLE vertices_tmp;
        	EXCEPTION 
			WHEN UNDEFINED_TABLE THEN
                END;
                    						    
		CREATE TABLE vertices_tmp ( id serial );	

                							
		FOR i IN EXECUTE 'SELECT srid FROM geometry_columns WHERE f_table_name='''|| quote_ident(geom_table)||'''' LOOP
		END LOOP;
		srid := i.srid;
		
		EXECUTE 'SELECT addGeometryColumn(''vertices_tmp'', ''the_geom'', '||srid||', ''POINT'', 2)';
                    							                                                 
                CREATE INDEX vertices_tmp_idx ON vertices_tmp USING GIST (the_geom);
		
		BEGIN
			EXECUTE 'ALTER TABLE '||quote_ident(geom_table)||' add column source int4';
		EXCEPTION
			WHEN DUPLICATE_COLUMN THEN
		END;
		BEGIN
			EXECUTE 'ALTER TABLE '||quote_ident(geom_table)||' add column target int4';
		EXCEPTION
			WHEN DUPLICATE_COLUMN THEN
		END;

		FOR points IN EXECUTE 'SELECT ' || quote_ident(gid_cname) || ' AS id,'
			|| ' relaxed_PointN('|| quote_ident(geo_cname) ||', 1) AS source,'
			|| ' relaxed_PointN('|| quote_ident(geo_cname) ||', relaxed_NumPoints('|| quote_ident(geo_cname) ||')) as target'
			|| ' FROM ' || quote_ident(geom_table) loop

				source_id := point_to_id(setsrid(points.source, srid), tolerance);
				target_id := point_to_id(setsrid(points.target, srid), tolerance);
                    							                                                        	
				EXECUTE 'update ' || quote_ident(geom_table) || 
				    ' SET source = ' || source_id || 
                        	    ', target = ' || target_id || 
                                    ' WHERE ' || quote_ident(gid_cname) || ' =  ' || points.id;
        END LOOP;
                    							                                                        														                                                            
RETURN 'OK';

END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT; 


-----------------------------------------------------------------------
-- Fill the source and target column for all lines. All line ends
--  with a distance less than tolerance, are assigned the same id
-----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION assign_vertex_id(geom_table varchar, 
       tolerance double precision)
       RETURNS VARCHAR AS
$$
DECLARE
	row record;
BEGIN
		SELECT INTO row assign_vertex_id(geom_table,tolerance,'the_geom','gid') AS r;
		return row.r;

END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT; 


