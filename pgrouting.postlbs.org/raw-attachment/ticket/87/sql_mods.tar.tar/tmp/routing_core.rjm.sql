--
-- Copyright (c) 2005 Sylvain Pasche,
--               2006-2007 Anton A. Patrushev, Orkney, Inc.
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
--

-----------------------------------------------------------------------
-- Create the vertices and edges tables from a table matching the 
--  geometry schema described above.
-----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION create_graph_tables(geom_table varchar) 
       RETURNS void AS
$$
BEGIN
		EXECUTE 'SELECT create_graph_tables('||quote_literal(geom_table)||',''int4'',' || '''gid'' ,''source'',''target'')';
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;

CREATE OR REPLACE FUNCTION create_graph_tables(geom_table varchar, 
       column_type varchar )
       RETURNS void AS
$$
BEGIN
		EXECUTE 'SELECT create_graph_tables('||quote_literal(geom_table)||','||quote_literal(column_type)||',' || '''gid'' ,''source'',''target'')';
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;

CREATE OR REPLACE FUNCTION create_graph_tables(geom_table varchar, 
       column_type varchar , id_name varchar)
       RETURNS void AS
$$
BEGIN
		EXECUTE 'SELECT create_graph_tables('||quote_literal(geom_table)||','||quote_literal(column_type)||',' || quote_literal(id_name) || ' ,''source'',''target'')';
	RETURN;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;


CREATE OR REPLACE FUNCTION create_graph_tables(geom_table varchar, 
       column_type varchar, id_name varchar,source_name varchar,target_name varchar)
       RETURNS void AS
$$
BEGIN
    EXECUTE 'SELECT create_graph_tables('||quote_literal(geom_table)||','||quote_literal(column_type)||',' || quote_literal(id_name) || ','||quote_literal(source_name)||','||quote_literal(target_name)||',''4326'',''the_geom'')';
    RETURN;
END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;




CREATE OR REPLACE FUNCTION create_graph_tables(geom_table varchar, 
       column_type varchar, id_name varchar,source_name varchar,target_name varchar,srid varchar,geocol varchar)
       RETURNS void AS
$$
DECLARE
	nid int;
        geom record;
        edge_id int;
        myrec record;
        source_id int;
        target_id int;
        vertices_table varchar := quote_ident(geom_table) || '_vertices';
        edges_table varchar := quote_ident(geom_table) || '_edges';
BEGIN

        EXECUTE 'CREATE TABLE ' || vertices_table || 
                ' (id serial, geom_id ' || quote_ident(column_type) || 
                '  NOT NULL UNIQUE)';

        EXECUTE 'CREATE INDEX ' || vertices_table || '_id_idx on ' || 
                vertices_table || ' (id)';

        EXECUTE 'CREATE TABLE ' || edges_table || 
                ' (gid serial, source int, target int, ' || 
                'cost float8, reverse_cost float8, UNIQUE (gid, source, target))';

        EXECUTE 'CREATE INDEX ' || edges_table || 
                '_source_target_idx on ' || edges_table || 
                ' (source, target)';

	BEGIN
		EXECUTE 'ALTER TABLE ' || quote_ident(geom_table) ||' ADD COLUMN edge_id int4';
	EXCEPTION 
		WHEN DUPLICATE_COLUMN THEN
	END;

	-- add the geometry column to the _edges table
	BEGIN
		EXECUTE 'SELECT addGeometryColumn('''||quote_ident(edges_table)||
			''',''the_geom'''||
			','||quote_literal(srid)||
			',GeometryType((SELECT '||quote_ident(geocol)||
					' from '||quote_ident(geom_table)||
					' limit 1)),2)';
	EXCEPTION
		WHEN DUPLICATE_COLUMN THEN
	END;


        FOR geom IN EXECUTE 'SELECT '|| quote_ident(id_name) ||' as id, ' || 
				quote_ident(source_name) ||
             ' AS source, ' ||
			quote_ident(geocol)||' AS the_geom ,'||
				quote_ident(target_name) ||
             ' AS target FROM ' || quote_ident(geom_table) LOOP

                SELECT INTO source_id insert_vertex(vertices_table, 
                                                    geom.source);

                SELECT INTO target_id insert_vertex(vertices_table, 
                                                    geom.target);

                BEGIN
		    SELECT INTO nid nextval(quote_ident(edges_table)||'_gid_seq');
                    EXECUTE 'INSERT INTO ' || edges_table || 
                            ' (gid,source, target) VALUES ('  ||
			    nid||','||	
                            quote_literal(source_id) || ', ' || 
                            quote_literal(target_id) || ')';

                EXCEPTION 
                        WHEN UNIQUE_VIOLATION THEN
                END;

                EXECUTE 'UPDATE ' || quote_ident(geom_table) || 
                        ' SET edge_id = ' || nid || 
                        ' WHERE ' || quote_ident(id_name) || ' =  ' || geom.id;
        END LOOP;

	-- copy the_geom values from geom_table to _edges table
	-- NB. there may (but shouoldn't be!) be more than one geometry 
	--     per edge, this picks one arbitrarily
	EXECUTE 'UPDATE '||quote_ident(edges_table)||
			' SET the_geom = (select st_transform('||
			quote_ident(geocol)||','||quote_literal(srid)||
			') from '||
			quote_ident(geom_table)||' where '||
	       		quote_ident(geom_table)||'.edge_id = '||
			quote_ident(edges_table)||'.gid limit 1)';

        RETURN;

END;
$$
LANGUAGE 'plpgsql' VOLATILE STRICT;

-----------------------------------------------------------------------
-- Compute the shortest path using edges and vertices table, and return
--  the result as a set of (gid integer, the_geom gemoetry) records.
-- This function uses the internal vertices identifiers.
-- NB. use dijkstra_sp('(tabname)_edges', ... ) instead !
-----------------------------------------------------------------------
--
-- Sometimes imported graphs have problems: unremedied the distances can be multiplied
-- class is the column name which determines primary precedence with lower values 
-- having higher priority. Only one record is kept for each distinct geometry.
-- pkey is the unique primary key for the 'tab' geotable.
--
CREATE OR REPLACE FUNCTION remove_duplicate_geoms(tab varchar,geocol varchar,class varchar,pkey varchar)
    RETURNS void AS
$$
DECLARE
    row record;
    row2 record;
BEGIN
    -- find duplicate rows having the same geometry,choose the lowest class to keep
    FOR row IN EXECUTE 
	    'select astext('||quote_ident(geocol)||') as geom,min('||quote_ident(class)||') as class from '||
		quote_ident(tab)||' group by '||quote_ident(geocol)
		|| ' having count('||quote_ident(class)||') > 1'
    LOOP
		-- given the lowest class for each, get the primary key of one &  delete the rest
		EXECUTE 'select min('||quote_ident(pkey)||') as key from '||quote_ident(tab)||' where '||quote_ident(class)||
		' = '||row.class||' and astext('||quote_ident(geocol)||') = '''||row.geom||''' limit 1' 
	    INTO row2;
		EXECUTE 'delete from '||quote_ident(tab)||' where astext('||quote_ident(geocol)||') = '''||row.geom||
		''' and '||quote_ident(pkey)||' != '||row2.key;
    END LOOP;
	-- don't ask me ???
    EXECUTE 'delete from '||quote_ident(tab)||' where astext('||quote_ident(geocol)||') = '''||row.geom||
		''' and '||quote_ident(pkey)||' != '||row2.key;
END;
$$
LANGUAGE 'plpgsql' ;
